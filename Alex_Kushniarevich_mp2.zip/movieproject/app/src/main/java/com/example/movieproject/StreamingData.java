package com.example.movieproject;

// streaming data class and params
public class StreamingData {
    int streamingTitle;
    int streamingImage;

    public StreamingData(int streamingTitle, int streamingImage) {
        this.streamingTitle = streamingTitle;
        this.streamingImage = streamingImage;
    }
}
